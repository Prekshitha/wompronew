package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.AdminDaoIntf;
import com.model.Training;

@Service("adminservice")
public class AdminsServiceImpl implements AdminServiceIntf {

	@Autowired
	AdminDaoIntf admindao;
	
	@Transactional
	public List<Training> getTraining(){
		return admindao.gettraining();
	}
	
	@Transactional
	public int approvedonlyTrainingbyadmin(int tid) {
		return admindao.approvedonlyTrainingbyadmin(tid);
	}
}
