package com.service;

import java.util.List;

import com.model.Sukanya;

public interface MySukanyaServiceIntf {

	
	public boolean insertForm( Sukanya sukanya);
	public List<Sukanya> getUser();
}
