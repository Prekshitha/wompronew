package com.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="stepdetails")
public class Stepdetails {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private String stid;
	
	@OneToOne
	@JoinColumn(name = "tid")
	private Training trainingstep;
	
	@ManyToOne
	@JoinColumn(name = "stepid")
	private Step step;
	
	public Stepdetails() {
		super();
	}
	public String getStid() {
		return stid;
	}
	public void setStid(String stid) {
		this.stid = stid;
	}
	public Training getTrainingstep() {
		return trainingstep;
	}
	public void setTrainingstep(Training trainingstep) {
		this.trainingstep = trainingstep;
	}
	public Step getStep() {
		return step;
	}
	public void setStep(Step step) {
		this.step = step;
	}
	@Override
	public String toString() {
		return "Stepdetails [stid=" + stid + ", trainingstep=" + trainingstep + ", step=" + step + "]";
	}
	

	
}